//Ej1. Algoritmo que pida un numero y diga si es positivo, negativo o 0.
print("Introduce un numero");
var numero: Int = -1
if numero >= 0 {
if numero > 0{ 
  print("El numero es positivo")
}else{
  print("El numero es 0")
}
}else{
  print("El numero es negativo")
}



//Ej2. Escribe un programa que lea un numero e indique si es par o impar.
print("Introduce un numero");
var numero2: Int = 7
if(numero2 % 2 == 0){
  print("Es par")
}else{
  print("Es impar")
}

//Ej3. Escribe un programa que dado un nombre de usuario y una contrase 'f1a y si se ha introducido "pepe" y "asdasd" se indica "Has entrado al sistema",

print("Introduce un usuario")
var nombre: String = "pepe"
print("Introduce una contraseña") 
var contraseña: String = "asdad"
if(nombre == "pepe" && contraseña == "asdasd"){
  print("Has entrado en el sistema")
}else{
  print("Usuario o contraseña erroneos")
}

//Ej4. Programa que dada una cadena por teclado y compruebe si la primera letra es un "/" y la segunda un "*", en caso afirmativo se escribira la palabra entera, en caso contrario escribir "no es correcta".

var cadena: String = "/ff"
var char1: Character = cadena[cadena.startIndex]
var char2: Character = cadena[cadena.index(cadena.startIndex, offsetBy: 1)]
if(char1 == "/" && char2 == "*"){
  print(cadena)
}else{
  print("No es correcta")
}



//Ej5. Algoritmo que dado tres numeros y los muestre ordenados (de mayor a menor);
var nums = [68,14,47]
var ordenados = Array(nums.sorted().reversed())
print(ordenados)


//Ej6. Algoritmo que pida los puntos centrales x1,y1,x2,y2 y los radios r1,r2 de dos circunferencias y las clasifique en uno de estos estados:



//Ej7. Crea una aplicacion que pida un numero y calcule su factorial (El factorial de un numero es el producto de todos los enteros entre 1 y el propio numero y se representa por el numero seguido de un signo de exclamacion.

var n = 5
var factorial = 1

for i in 1...n{
factorial = factorial * i
}
print ("El factorial de \(n) es \(factorial)")

//Ej8. Algoritmo que cree un array con 10 numeros. Debe imprimir la suma y la media de todos los numeros introducidos.
var diezNum: [Int] = []
var suma = 0
var media : Double = 0

for _ in 1...10 {
  diezNum.append(Int.random(in: 0..<130))
}
print("Numeros generados ", diezNum)
for miNum in diezNum{
  suma+=miNum
}
media = Double(suma / diezNum.count)

print("La suma de los numeros es \(suma) y su media es \(media)")

//Ej9. Algoritmo que cree un array con 10 numeros. El programa debe informar de cuantos numeros introducidos son mayores que 0, menores que 0 e iguales a 0.

var arraynum = [-1,2,3,4,0,0,-5,-9,9,0]
var iguales = 0
var mayores = 0
var menores = 0
for index in arraynum{
if index < 0 {
  menores += 1
}else if index > 0{
  mayores += 1
}else{
  iguales += 1
}

}
print("Hay \(mayores) mayores que 0")
print("Hay \(menores) menores que 0")
print("Hay \(iguales) iguales que 0")
//Ej 10 Escribir un programa que imprima todos los numeros pares entre dos numeros

var num1 = 3
var num2 = 15
var numpar = 0
var listaNumerosPares = [Int]()

for index in num1...num2 {
  if index % 2 == 0{
    numpar+=1
    listaNumerosPares.append(index)
  }
}
print("Numero de pares", numpar)
print("Numeros pares", listaNumerosPares)
//Ej 11 Una empresa tiene el registro de las horas que trabaja diariamente un empleado durante la semana (seis d'edas), as'ed como el sueldo que recibir'e1 por las horas trabajadas. Las horas estan en un array y el precio hora esta en 30'80}

var horas = ["lunes" : 3, "martes": 4, "miercoles": 2, "jueves": 5, "viernes":8, "sabado": 6]
let precioHora = 30
var salario = 0

for horas in horas.values{
  salario += precioHora * horas
}
print("Salario total", salario)