/*var x : Int = 15
var y : Int = 20
var peri : Int = 0
var area : Int = 0
peri = 2*x+2*y
area = (x*y)
print(peri)
print(area)*/

/*var a: Double = 15.0
var b: Double = 20.0
var c : Double = 0
c=((a*a)+(b*b)).squareRoot()

print(c)

var x : Double = 13
var y : Double = 31
var suma :  Double = x+y
var resta : Double = x-y
var mult : Double = x*y
var div : Double = x/y

print(suma)
print(resta)
print(mult)
print(div)

var f : Double = 125.4
var cel : Double = (f - 32) * 5/9
print(cel)

var a : Double = 13
var b : Double = 31
var c : Double = 23

var media : Double = (a + b + c)/3
print(media)
var sue : Double = 100
var comi : Double = 0.1
var v1 : Double = 3000
var v2 : Double = 1000
var v3 : Double = 2000
var totalComi : Double = v1*comi + v2 * comi + v3 * comi
var totalsue : Double = sue + totalComi
print(totalComi)
print(totalsue)
var n1 : Double = 3
var n2 : Double = 6
var n3 : Double = 8
var nf : Double = 7.3
var tf : Double = 5.8
var prom : Double = 0.55
var cf : Double = 0.3
var ct : Double = 0.15
var mediaPar : Double = (n1 + n2 + n3) / 3
var notaFinal = (mediaPar * prom) + (nf * cf) + (ct * tf)
print(notaFinal)

var correct : Int = 5
var incorrect : Int = -1
var blan : Int = 0
var nota = (5 * correct + 0 * incorrect + 5 * blan ) / 5
print(nota) */

var suel : Double = 300000
var horasExtr : Double? = 5
var sueExt :Double = 10
var horasTotal : Double = sueExt * (horasExtr ?? 0)
var total = suel + horasTotal
print(total)

